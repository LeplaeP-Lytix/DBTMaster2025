with example_silver as (
    select * from {{ ref('example_model') }}
)
select * from example_silver
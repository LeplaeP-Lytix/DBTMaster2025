with source as (
    select * from {{ source('raw_layer','example') }}
)

select * from source